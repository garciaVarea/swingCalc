package com.calc;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;

public class Escritorio {

	private JFrame frmAplicacinDeJava;
	private JTextField txtPantalla;
	
	//VARIABLES
	double numero1;
	double numero2;
	double resultado;
	String operacion;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Escritorio window = new Escritorio();
					window.frmAplicacinDeJava.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Escritorio() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAplicacinDeJava = new JFrame();
		frmAplicacinDeJava.getContentPane().setBackground(new Color(112, 128, 144));
		frmAplicacinDeJava.setTitle("Calculadora");
		frmAplicacinDeJava.setBounds(100, 100, 315, 433);
		frmAplicacinDeJava.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAplicacinDeJava.getContentPane().setLayout(null);
		
		
		
		txtPantalla = new JTextField();
		txtPantalla.setFont(new Font("NSimSun", Font.PLAIN, 36));
		txtPantalla.setBackground(new Color(240, 255, 255));
		txtPantalla.setHorizontalAlignment(SwingConstants.RIGHT);
		txtPantalla.setBounds(40, 38, 224, 53);
		frmAplicacinDeJava.getContentPane().add(txtPantalla);
		txtPantalla.setColumns(10);
		
		JButton btnClean = new JButton("C");
		btnClean.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtPantalla.setText("");
			}
		});
		btnClean.setBackground(new Color(255, 0, 0));
		btnClean.setFont(new Font("Arial", Font.BOLD, 18));
		btnClean.setBounds(217, 118, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btnClean);
		
		JButton btnSuma = new JButton("+");
		btnSuma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//SUMA
				numero1 =Double.parseDouble(txtPantalla.getText());
				txtPantalla.setText("");;
				operacion="+";
			}
		});
		btnSuma.setBackground(new Color(0, 191, 255));
		btnSuma.setFont(new Font("Arial", Font.BOLD, 22));
		btnSuma.setBounds(217, 168, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btnSuma);
		
		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//NUM 3
				String IngreseNumero = txtPantalla.getText()+btn3.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn3.setBackground(new Color(255, 255, 0));
		btn3.setFont(new Font("Arial", Font.BOLD, 22));
		btn3.setBounds(158, 168, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn3);
		
		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//NUM 2
				String IngreseNumero = txtPantalla.getText()+btn2.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn2.setBackground(new Color(255, 255, 0));
		btn2.setFont(new Font("Arial", Font.BOLD, 22));
		btn2.setBounds(99, 168, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn2);
		
		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//NUM 1
				String IngreseNumero = txtPantalla.getText()+btn1.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn1.setBackground(new Color(255, 255, 0));
		btn1.setFont(new Font("Arial", Font.BOLD, 22));
		btn1.setBounds(40, 168, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn1);
		
		JButton btnResta = new JButton("-");
		btnResta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//RESTA
				numero1 =Double.parseDouble(txtPantalla.getText());
				txtPantalla.setText("");;
				operacion="-";
			}
		});
		btnResta.setBackground(new Color(0, 191, 255));
		btnResta.setFont(new Font("Arial", Font.BOLD, 22));
		btnResta.setBounds(217, 216, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btnResta);
		
		JButton btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//NUM 6
				String IngreseNumero = txtPantalla.getText()+btn6.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn6.setBackground(new Color(255, 255, 0));
		btn6.setFont(new Font("Arial", Font.BOLD, 22));
		btn6.setBounds(158, 216, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn6);
		
		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//NUM 5
				String IngreseNumero = txtPantalla.getText()+btn5.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn5.setBackground(new Color(255, 255, 0));
		btn5.setFont(new Font("Arial", Font.BOLD, 22));
		btn5.setBounds(99, 216, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn5);
		
		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//NUM 4
				String IngreseNumero = txtPantalla.getText()+btn4.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn4.setBackground(new Color(255, 255, 0));
		btn4.setFont(new Font("Arial", Font.BOLD, 22));
		btn4.setBounds(40, 216, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn4);
		
		JButton btnMultip = new JButton("x");
		btnMultip.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//MULTIPLICACIÓN
				numero1 =Double.parseDouble(txtPantalla.getText());
				txtPantalla.setText("");;
				operacion="*";
			}
		});
		btnMultip.setBackground(new Color(0, 191, 255));
		btnMultip.setFont(new Font("Arial", Font.BOLD, 22));
		btnMultip.setBounds(217, 263, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btnMultip);
		
		JButton btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//NUM 9
				String IngreseNumero = txtPantalla.getText()+btn9.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn9.setBackground(new Color(255, 255, 0));
		btn9.setFont(new Font("Arial", Font.BOLD, 22));
		btn9.setBounds(158, 263, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn9);
		
		JButton btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//NUM 8
				String IngreseNumero = txtPantalla.getText()+btn8.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn8.setBackground(new Color(255, 255, 0));
		btn8.setFont(new Font("Arial", Font.BOLD, 22));
		btn8.setBounds(99, 263, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn8);
		
		JButton btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() {
			//NUMERO 7
			public void actionPerformed(ActionEvent e) {
				String IngreseNumero = txtPantalla.getText()+btn7.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn7.setBackground(new Color(255, 255, 0));
		btn7.setFont(new Font("Arial", Font.BOLD, 22));
		btn7.setBounds(40, 263, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn7);
		
		JButton btnDiv = new JButton("/");
		btnDiv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//DIVISIÓN
				numero1 =Double.parseDouble(txtPantalla.getText());
				txtPantalla.setText("");;
				operacion="/";
			}
		});
		btnDiv.setBackground(new Color(0, 191, 255));
		btnDiv.setFont(new Font("Arial", Font.BOLD, 22));
		btnDiv.setBounds(217, 311, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btnDiv);
		
		JButton btnIgual = new JButton("=");
		btnIgual.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String seleccionar;
				numero2=Double.parseDouble(txtPantalla.getText());
				if (operacion=="+") {
					resultado=numero1+numero2;
					seleccionar=String.format("%.2f", resultado);
					txtPantalla.setText(seleccionar);
				}
				else if (operacion=="-") {
					resultado=numero1-numero2;
					seleccionar=String.format("%.2f", resultado);
					txtPantalla.setText(seleccionar);
				}
				else if (operacion=="*") {
					resultado=numero1*numero2;
					seleccionar=String.format("%.2f", resultado);
					txtPantalla.setText(seleccionar);
				}
				else if (operacion=="/") {
					resultado=numero1/numero2;
					seleccionar=String.format("%.2f", resultado);
					txtPantalla.setText(seleccionar);
				}
			}
		});
		btnIgual.setBackground(new Color(0, 255, 0));
		btnIgual.setFont(new Font("Arial", Font.BOLD, 22));
		btnIgual.setBounds(158, 311, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btnIgual);
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//NUM 0
				String IngreseNumero = txtPantalla.getText()+btn0.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btn0.setBackground(new Color(255, 255, 0));
		btn0.setFont(new Font("Arial", Font.BOLD, 22));
		btn0.setBounds(99, 311, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btn0);
		
		JButton btnPunto = new JButton(".");
		btnPunto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String IngreseNumero = txtPantalla.getText()+btnPunto.getText();
				txtPantalla.setText(IngreseNumero);
			}
		});
		btnPunto.setBackground(new Color(244, 164, 96));
		btnPunto.setFont(new Font("Arial", Font.BOLD, 22));
		btnPunto.setBounds(40, 311, 49, 46);
		frmAplicacinDeJava.getContentPane().add(btnPunto);
	}
}
